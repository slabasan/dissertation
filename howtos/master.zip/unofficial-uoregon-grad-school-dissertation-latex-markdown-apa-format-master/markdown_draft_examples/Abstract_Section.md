<!-- 
Rules (from https://gradschool.uoregon.edu/sites/gradschool2.uoregon.edu/files/ETD_Style_Manual_2015-2016final032016.pdf):

* Cannot exceed 350 words ("Hyphenated words count as one word")
* "Because the Abstract must be able to stand alone, apart from the body of the ETD, do not include parenthetical (author, date) reference citations"
* 
-->

This is where the text of your Abstract will go. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed hendrerit consequat tristique. Duis venenatis tempus nisi vitae tempor. Maecenas ac efficitur magna. Aenean aliquam vel nibh in gravida. Sed risus lectus, egestas sed dignissim ac, ultrices sit amet purus. Vestibulum quis purus dapibus, iaculis arcu vitae, lacinia sem. Duis consequat enim sit amet ante dapibus porttitor. Morbi id nisl a est feugiat iaculis. 

This is the second paragraph of the abstract. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed hendrerit consequat tristique. Duis venenatis tempus nisi vitae tempor. Maecenas ac efficitur magna. Aenean aliquam vel nibh in gravida. Sed risus lectus, egestas sed dignissim ac, ultrices sit amet purus. Vestibulum quis purus dapibus, iaculis arcu vitae, lacinia sem. Duis consequat enim sit amet ante dapibus porttitor. Morbi id nisl a est feugiat iaculis.


